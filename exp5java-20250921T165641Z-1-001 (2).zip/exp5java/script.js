// script.js
window.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('helloBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      alert('HELLO HARSHIT');
    });
  } else {
    console.error('Button not found!');
  }
});
  