import React from 'react';

function Home() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2>Welcome to the React SPA!</h2>
      <p>This is the Home page.</p>
    </div>
  );
}

export default Home;
