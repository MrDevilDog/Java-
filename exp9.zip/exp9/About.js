import React from 'react';

function About({ info }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2>About the Developer</h2>
      <p><strong>Name:</strong> {info.name}</p>
      <p><strong>Profession:</strong> {info.profession}</p>
      <p><strong>Email:</strong> {info.email}</p>
    </div>
  );
}

export default About;
